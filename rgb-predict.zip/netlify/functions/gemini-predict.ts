import { GoogleGenAI } from '@google/genai';
import type { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";

// Get the API key from environment variables
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This will be visible in the function logs on Netlify
  throw new Error('API_KEY is not set in environment variables.');
}

// Initialize the GoogleGenAI client with the API key
const ai = new GoogleGenAI({ apiKey: API_KEY });

const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method Not Allowed' }),
    };
  }

  try {
    // Parse the incoming request body from the frontend
    const { prompt, responseSchema } = JSON.parse(event.body || '{}');

    // Basic validation
    if (!prompt || !responseSchema) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing prompt or responseSchema in request body.' }),
      };
    }

    // Call the Gemini API
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
      },
    });
    
    // The Gemini API returns the JSON as a string in the 'text' property
    const resultJson = JSON.parse(response.text);

    // Send the successful JSON response back to the frontend
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(resultJson),
    };

  } catch (error) {
    console.error('Error in Gemini API call:', error);
    // Send a generic error message back to the frontend
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'An internal server error occurred.' }),
    };
  }
};

export { handler };
